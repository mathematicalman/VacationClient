﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using VacationClient.ServiceReference;

namespace VacationClient
{
    public partial class OrderForm : Form
    {
        public delegate void UpdateOrderDelegate(Order order);
        public delegate void AddOrderDelegate(Order order);
        private UpdateOrderDelegate updateOrder;
        private AddOrderDelegate addOrder;
        private Order order;
        private string format = "dd-MM-yyyy";
        private int? id;

        public OrderForm(AddOrderDelegate _addOrder)
        {
            InitializeComponent();
            addOrder = _addOrder;
            order = new Order();
            id = null;
            comboBox1.SelectedIndex = 0;
            bindDays();
            textBox1.Text = monthCalendar1.SelectionStart.ToString(format);
            textBox2.Text = monthCalendar2.SelectionStart.ToString(format);
        }

        public OrderForm(UpdateOrderDelegate _updateOrder, Order _order)
        {
            InitializeComponent();
            updateOrder = _updateOrder;
            order = _order;
            id = order.id;
            comboBox1.SelectedIndex = (int)order.type;
            bindDays();
            textBox1.Text = order.begin.ToString(format);
            textBox2.Text = order.end.ToString(format);
        }

        private void bindDays()
        {
            textBox1.TextChanged += DatesChanged;
            textBox2.TextChanged += DatesChanged;
        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            monthCalendar1.Visible = true;
        }

        private void textBox2_MouseClick(object sender, MouseEventArgs e)
        {
            monthCalendar2.Visible = true;
        }

        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
            monthCalendar1.Visible = false;
            textBox1.Text = monthCalendar1.SelectionStart.ToString(format);
        }

        private void monthCalendar2_DateSelected(object sender, DateRangeEventArgs e)
        {
            monthCalendar2.Visible = false;
            textBox2.Text = monthCalendar2.SelectionStart.ToString(format);
        }

        private void DatesChanged(object sender, EventArgs e)
        {
            double diff = (monthCalendar2.SelectionStart - monthCalendar1.SelectionStart).TotalDays;
            textBox3.Text = diff.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            order.type = (OrderType)comboBox1.SelectedIndex;
            order.begin = DateTime.ParseExact(textBox1.Text, format, System.Globalization.CultureInfo.InvariantCulture);
            order.end = DateTime.ParseExact(textBox2.Text, format, System.Globalization.CultureInfo.InvariantCulture);
            if (id == null)
                addOrder(order);
            else 
                updateOrder(order);
            this.Close();
        }
    }
}
