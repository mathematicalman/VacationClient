﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.ServiceModel;
using System.Text;
using System.Windows.Forms;

namespace VacationClient
{
    public partial class Login : Form
    {
        public delegate bool OpenConnectionDelegate(string host);
        public delegate bool LoginDelegate(string username, string password);
        private OpenConnectionDelegate openConnection;
        private LoginDelegate login;

        public Login(OpenConnectionDelegate _openConnection, LoginDelegate _login)
        {
            openConnection = _openConnection;
            login = _login;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!openConnection(textBox1.Text)) return;
            if (login(textBox2.Text, textBox3.Text)) {
                DialogResult = DialogResult.OK;
                Close();
            }
        }
    }
}
