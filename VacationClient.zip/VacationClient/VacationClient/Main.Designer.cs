﻿namespace VacationClient
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.MyOrderId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MyType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MyDateBegin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MyDateEnd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MyDays = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MyStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.AllOrderId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AllUserId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AllUserName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AllType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AllDateBegin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AllDateEnd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AllDays = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AllStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.orderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(434, 198);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(426, 172);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "My orders";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(168, 138);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "ReSend";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(87, 138);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Delete";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 138);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Edit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.CausesValidation = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MyOrderId,
            this.MyType,
            this.MyDateBegin,
            this.MyDateEnd,
            this.MyDays,
            this.MyStatus});
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new System.Drawing.Point(6, 6);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(414, 126);
            this.dataGridView1.TabIndex = 0;
            // 
            // MyOrderId
            // 
            this.MyOrderId.DataPropertyName = "id";
            this.MyOrderId.HeaderText = "OrderId";
            this.MyOrderId.Name = "MyOrderId";
            this.MyOrderId.ReadOnly = true;
            this.MyOrderId.Visible = false;
            // 
            // MyType
            // 
            this.MyType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.MyType.DataPropertyName = "type";
            this.MyType.HeaderText = "Type";
            this.MyType.Name = "MyType";
            this.MyType.ReadOnly = true;
            this.MyType.Width = 56;
            // 
            // MyDateBegin
            // 
            this.MyDateBegin.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.MyDateBegin.DataPropertyName = "begin";
            dataGridViewCellStyle13.Format = "dd-MM-yyyy";
            dataGridViewCellStyle13.NullValue = null;
            this.MyDateBegin.DefaultCellStyle = dataGridViewCellStyle13;
            this.MyDateBegin.HeaderText = "Date begin";
            this.MyDateBegin.Name = "MyDateBegin";
            this.MyDateBegin.ReadOnly = true;
            this.MyDateBegin.Width = 84;
            // 
            // MyDateEnd
            // 
            this.MyDateEnd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.MyDateEnd.DataPropertyName = "end";
            dataGridViewCellStyle14.Format = "dd-MM-yyyy";
            this.MyDateEnd.DefaultCellStyle = dataGridViewCellStyle14;
            this.MyDateEnd.HeaderText = "Date end";
            this.MyDateEnd.Name = "MyDateEnd";
            this.MyDateEnd.ReadOnly = true;
            this.MyDateEnd.Width = 76;
            // 
            // MyDays
            // 
            this.MyDays.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.MyDays.DataPropertyName = "days";
            this.MyDays.HeaderText = "Days";
            this.MyDays.Name = "MyDays";
            this.MyDays.ReadOnly = true;
            this.MyDays.Width = 56;
            // 
            // MyStatus
            // 
            this.MyStatus.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.MyStatus.DataPropertyName = "status";
            this.MyStatus.HeaderText = "Status";
            this.MyStatus.Name = "MyStatus";
            this.MyStatus.ReadOnly = true;
            this.MyStatus.Width = 62;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(426, 172);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "All orders";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(87, 138);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 2;
            this.button7.Text = "Reject";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(6, 138);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 1;
            this.button6.Text = "Confirm";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.AllOrderId,
            this.AllUserId,
            this.AllUserName,
            this.AllType,
            this.AllDateBegin,
            this.AllDateEnd,
            this.AllDays,
            this.AllStatus});
            this.dataGridView2.Location = new System.Drawing.Point(6, 6);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(414, 126);
            this.dataGridView2.TabIndex = 0;
            // 
            // AllOrderId
            // 
            this.AllOrderId.DataPropertyName = "id";
            this.AllOrderId.HeaderText = "Order id";
            this.AllOrderId.Name = "AllOrderId";
            this.AllOrderId.ReadOnly = true;
            // 
            // AllUserId
            // 
            this.AllUserId.DataPropertyName = "userId";
            this.AllUserId.HeaderText = "User id";
            this.AllUserId.Name = "AllUserId";
            this.AllUserId.ReadOnly = true;
            // 
            // AllUserName
            // 
            this.AllUserName.DataPropertyName = "userName";
            this.AllUserName.HeaderText = "User name";
            this.AllUserName.Name = "AllUserName";
            this.AllUserName.ReadOnly = true;
            // 
            // AllType
            // 
            this.AllType.DataPropertyName = "type";
            this.AllType.HeaderText = "Type";
            this.AllType.Name = "AllType";
            this.AllType.ReadOnly = true;
            // 
            // AllDateBegin
            // 
            this.AllDateBegin.DataPropertyName = "begin";
            dataGridViewCellStyle15.Format = "dd-MM-yyyy";
            this.AllDateBegin.DefaultCellStyle = dataGridViewCellStyle15;
            this.AllDateBegin.HeaderText = "Date degin";
            this.AllDateBegin.Name = "AllDateBegin";
            this.AllDateBegin.ReadOnly = true;
            // 
            // AllDateEnd
            // 
            this.AllDateEnd.DataPropertyName = "end";
            dataGridViewCellStyle16.Format = "dd-MM-yyyy";
            this.AllDateEnd.DefaultCellStyle = dataGridViewCellStyle16;
            this.AllDateEnd.HeaderText = "Date end";
            this.AllDateEnd.Name = "AllDateEnd";
            this.AllDateEnd.ReadOnly = true;
            // 
            // AllDays
            // 
            this.AllDays.DataPropertyName = "days";
            this.AllDays.HeaderText = "Days";
            this.AllDays.Name = "AllDays";
            this.AllDays.ReadOnly = true;
            // 
            // AllStatus
            // 
            this.AllStatus.DataPropertyName = "status";
            this.AllStatus.HeaderText = "Status";
            this.AllStatus.Name = "AllStatus";
            this.AllStatus.ReadOnly = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(12, 227);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(148, 23);
            this.button4.TabIndex = 1;
            this.button4.Text = "Update tables";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(292, 227);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(154, 23);
            this.button5.TabIndex = 2;
            this.button5.Text = "Send new order";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // orderBindingSource
            // 
            this.orderBindingSource.DataSource = typeof(VacationClient.ServiceReference.Order);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(458, 262);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.tabControl1);
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Main_FormClosed);
            this.Load += new System.EventHandler(this.Main_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource orderBindingSource;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.DataGridViewTextBoxColumn MyOrderId;
        private System.Windows.Forms.DataGridViewTextBoxColumn MyType;
        private System.Windows.Forms.DataGridViewTextBoxColumn MyDateBegin;
        private System.Windows.Forms.DataGridViewTextBoxColumn MyDateEnd;
        private System.Windows.Forms.DataGridViewTextBoxColumn MyDays;
        private System.Windows.Forms.DataGridViewTextBoxColumn MyStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn AllOrderId;
        private System.Windows.Forms.DataGridViewTextBoxColumn AllUserId;
        private System.Windows.Forms.DataGridViewTextBoxColumn AllUserName;
        private System.Windows.Forms.DataGridViewTextBoxColumn AllType;
        private System.Windows.Forms.DataGridViewTextBoxColumn AllDateBegin;
        private System.Windows.Forms.DataGridViewTextBoxColumn AllDateEnd;
        private System.Windows.Forms.DataGridViewTextBoxColumn AllDays;
        private System.Windows.Forms.DataGridViewTextBoxColumn AllStatus;
    }
}