﻿using System;
using System.ComponentModel;
using System.ServiceModel;
using System.Windows.Forms;
using VacationClient.ServiceReference;

namespace VacationClient
{
    public partial class Main : Form
    {
        private VacationServiceClient client;
        private bool connectionIsOpened = false;
        private bool isHR;
        private BindingList<Order> myOrders = new BindingList<Order>();
        private BindingList<Order> allOrders = new BindingList<Order>();

        private bool openConnection(string host)
        {
            if (connectionIsOpened) return true;
            try
            {
                Uri baseAddress = new Uri(host);
                BasicHttpBinding binding = new BasicHttpBinding();
                EndpointAddress ea = new EndpointAddress(host);
                client = new VacationServiceClient(binding, ea);
                client.OpenConnection();
                connectionIsOpened = true;
            }
            catch (UriFormatException ex)
            {
                MessageBox.Show("Incorrect service address");
            }
            catch (EndpointNotFoundException ex)
            {
                MessageBox.Show("Could not find service");
            }
            catch (FaultException<DatabaseFault> ex)
            {
                MessageBox.Show(ex.Reason.ToString());
            }
            return connectionIsOpened;
        }

        private void closeConnection()
        {
            try
            {
                client.CloseConnection();
                connectionIsOpened = false;
            }
            catch (NullReferenceException ex) { }
            catch (UriFormatException ex) { }
            catch (EndpointNotFoundException ex) { }
            catch (FaultException<DatabaseFault> ex) { }
        }

        private bool login(string username, string password) {
            try {
                bool userExists = client.Login(username, password);
                if (userExists)
                    return true;
                MessageBox.Show("Incorrect User or Password");
            }
            catch (FaultException<DatabaseFault> ex)
            {
                MessageBox.Show(ex.Reason.ToString());
            }
            return false;
        }

        public Main()
        {
            Login loginForm = new Login(openConnection, login);
            DialogResult result = loginForm.ShowDialog();
            loginForm.Dispose();
            if (result == DialogResult.OK)
                InitializeComponent();
            else
            {
                closeConnection();
                Environment.Exit(0);
            }     
        }

        private void Main_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = myOrders;
            isHR = client.GetIsHR();
            if (!isHR)
                tabControl1.TabPages.RemoveAt(1);
            else {
                dataGridView2.AutoGenerateColumns = false;
                dataGridView2.DataSource = allOrders;
            }
            updateTables();
        }

        private void updateOrder(Order order) {
            client.UpdateOrder(order);
        }

        private void addOrder(Order order)
        {
            client.AddOrder(order);
        }

        private void updateTables() {
            Order[] orders = client.GetMyOrders();
            myOrders.Clear();
            foreach (Order order in orders)
            {
                myOrders.Add(order);
            }
            if (isHR)
            {
                Array.Clear(orders, 0, orders.Length);
                orders = client.GetAllOrders();
                allOrders.Clear();
                foreach (Order order in orders)
                {
                    allOrders.Add(order);
                }
            }
        }

        private Order getMyCurrentOrder() {
            int currentOrderId = (int)dataGridView1.SelectedRows[0].Cells[0].Value;
            Order currentOrder = null;
            foreach (Order order in myOrders)
            {
                if (order.id == currentOrderId)
                {
                    currentOrder = order;
                    break;
                }
            }
            return currentOrder;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Order currentOrder = getMyCurrentOrder();
            if (!isHR && currentOrder.status != OrderStatus.reject) {
                MessageBox.Show("You can not edit orders with confirm or wait status.");
                return;
            }
            OrderForm orderForm = new OrderForm(updateOrder, currentOrder);
            orderForm.ShowDialog();
            updateTables();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            updateTables();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Order currentOrder = getMyCurrentOrder();
            if (!isHR && currentOrder.status != OrderStatus.reject)
            {
                MessageBox.Show("You can not delete orders with confirm or wait status.");
                return;
            }
            client.DeleteOrder(currentOrder.id);
            updateTables();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OrderForm orderForm = new OrderForm(addOrder);
            orderForm.ShowDialog();
            updateTables();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Order currentOrder = getMyCurrentOrder();
            if (!isHR && currentOrder.status != OrderStatus.reject)
            {
                MessageBox.Show("You can not resend orders with confirm or wait status.");
                return;
            }
            client.ReAddOrder(currentOrder.id);
            updateTables();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (!isHR) return;
            int currentOrderId = (int)dataGridView2.SelectedRows[0].Cells[0].Value;
            client.ConfirmOrder(currentOrderId);
            updateTables();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (!isHR) return;
            int currentOrderId = (int)dataGridView2.SelectedRows[0].Cells[0].Value;
            client.RejectOrder(currentOrderId);
            updateTables();
        }

        private void Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            closeConnection();
        }
    }
}
