﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VacationHost
{
    using System.ServiceModel;
    using System.ServiceModel.Description;
    using VacationService;
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("VacationService starting...");
            Type serviceType = typeof(VacationService);
            Uri serviceUri = new Uri("http://localhost:50508/VacationService");
            ServiceHost host = new ServiceHost(serviceType, serviceUri);
            try
            {
                host.AddServiceEndpoint(typeof(IVacationService), new BasicHttpBinding(), "VacationService");
                ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
                smb.HttpGetEnabled = true;
                host.Description.Behaviors.Add(smb);
                host.Open();
                Console.WriteLine("VacationService start.");
                Console.WriteLine("Press Enter to stop VacationService.");
                Console.ReadLine();
                host.Close();
            }
            catch (CommunicationException ce)
            {
                Console.WriteLine("An exception occurred: {0}", ce.Message);
                host.Abort();
            }
        }
    }
}
