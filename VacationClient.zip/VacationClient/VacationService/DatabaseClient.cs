﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.ServiceModel;
using System.Web;

namespace VacationService
{
    public class DatabaseClient
    {
        private static DatabaseClient instance = null;
        private SqlConnection connection;
        private int userId;
        private bool isHR;

        private DatabaseClient() {           
        }

        public static DatabaseClient getInstance() {
            if (instance == null) {
                instance = new DatabaseClient();
            }
            return instance;
        }

        public void connectionOpen() {
            try
            {
                connection = new SqlConnection();
                SqlConnectionStringBuilder connectionSB = new SqlConnectionStringBuilder();
                connectionSB.DataSource = "(LocalDB)\\MSSQLLocalDB";
                connectionSB.AttachDBFilename = "|DataDirectory|\\VacationDatabase.mdf";
                connectionSB.ConnectTimeout = 30;
                connectionSB.IntegratedSecurity = true;
                connection.ConnectionString = connectionSB.ConnectionString;
                connection.Open();
            }
            catch (SqlException e)
            {
                throw new FaultException<DatabaseFault>(new DatabaseFault(e.Message), new FaultReason("Could not open connection"));
            }
        }

        public void connectionClose() {
            try
            {
                connection.Close();               
            }
            catch (SqlException e)
            {
                throw new FaultException<DatabaseFault>(new DatabaseFault(e.Message), new FaultReason("Could not close connection"));
            }
            finally
            {
                connection.Dispose();
            }
        }

        public bool login(string name, string password)
        {
            bool exists = false;
            string sql = string.Format("SELECT Id,IsHR FROM Users WHERE Name LIKE @name AND Pass=@password");
            try {
                using (SqlCommand cmd = new SqlCommand(sql, connection))
                {
                    SqlParameter param = new SqlParameter();
                    param.ParameterName = "@name";
                    param.Value = name;
                    param.SqlDbType = SqlDbType.Text;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@password";
                    param.Value = password;
                    param.SqlDbType = SqlDbType.Char;
                    param.Size = 32;
                    cmd.Parameters.Add(param);

                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        userId = (int)reader["Id"];
                        isHR = (bool)reader["IsHR"];
                        exists = true;
                    }
                    reader.Close();
                }
            } catch (SqlException e) {
                throw new FaultException<DatabaseFault>(new DatabaseFault(e.Message), new FaultReason("Could not login"));
            }
            return exists;
        }

        public bool getIsHR() {
            return isHR;
        }

        public List<Order> getMyOrders() {
            string sql = string.Format("SELECT Orders.Id,Orders.IdUser,Users.Name,Orders.Type,Orders.DateBegin,Orders.DateEnd,Orders.Status FROM Orders,Users WHERE Orders.IdUser=Users.Id AND Users.Id=@userid");
            List<Order> orders = new List<Order>();
            try {
                using (SqlCommand cmd = new SqlCommand(sql, connection))
                {
                    SqlParameter param = new SqlParameter();
                    param.ParameterName = "@userid";
                    param.Value = userId;
                    param.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(param);

                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Order order = new Order();
                        order.id = (int)reader["Id"];
                        order.userId = (int)reader["IdUser"];
                        order.userName = (string)reader["Name"];
                        order.type = (OrderType)reader["Type"];
                        order.begin = (DateTime)reader["DateBegin"];
                        order.end = (DateTime)reader["DateEnd"];
                        order.status = (OrderStatus)reader["Status"];
                        orders.Add(order);
                    }
                    reader.Close();
                }
            } catch (SqlException e) {
                throw new FaultException<DatabaseFault>(new DatabaseFault(e.Message), new FaultReason("Could not get orders"));
            }
            return orders;
        }

        public List<Order> getAllOrders()
        {
            if(!isHR)
                return new List<Order>();
            string sql = string.Format("SELECT Orders.Id,Orders.IdUser,Users.Name,Orders.Type,Orders.DateBegin,Orders.DateEnd,Orders.Status FROM Orders,Users WHERE Orders.IdUser=Users.Id");
            List<Order> orders = new List<Order>();
            try {
                using (SqlCommand cmd = new SqlCommand(sql, connection))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Order order = new Order();
                        order.id = (int)reader["Id"];
                        order.userId = (int)reader["IdUser"];
                        order.userName = (string)reader["Name"];
                        order.type = (OrderType)reader["Type"];
                        order.begin = (DateTime)reader["DateBegin"];
                        order.end = (DateTime)reader["DateEnd"];
                        order.status = (OrderStatus)reader["Status"];
                        orders.Add(order);
                    }
                    reader.Close();
                }
            } catch (SqlException e) {
                throw new FaultException<DatabaseFault>(new DatabaseFault(e.Message), new FaultReason("Could not get all orders"));
            }
            return orders;
        }

        public void addOrder(Order order)
        {
            string sql = isHR ? 
                string.Format("INSERT INTO Orders(IdUser,Type,DateBegin,DateEnd,Status) VALUES(@userid,@type,@datebegin,@dateend,1)") : 
                string.Format("INSERT INTO Orders(IdUser,Type,DateBegin,DateEnd) VALUES(@userid,@type,@datebegin,@dateend)");
            try {
                using (SqlCommand cmd = new SqlCommand(sql, connection))
                {
                    SqlParameter param = new SqlParameter();
                    param.ParameterName = "@userid";
                    param.Value = userId;
                    param.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@type";
                    param.Value = order.type;
                    param.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@datebegin";
                    param.Value = order.begin;
                    param.SqlDbType = SqlDbType.Date;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@dateend";
                    param.Value = order.end;
                    param.SqlDbType = SqlDbType.Date;
                    cmd.Parameters.Add(param);

                    cmd.ExecuteNonQuery();
                }
            } catch (SqlException e) {
                throw new FaultException<DatabaseFault>(new DatabaseFault(e.Message), new FaultReason("Could not add order"));
            }
        }

        public void deleteOrder(int orderId)
        {
            string sql = isHR ? 
                string.Format("DELETE FROM Orders WHERE Id=@orderid") :
                string.Format("DELETE FROM Orders WHERE Id=@orderid AND IdUser=@userid AND Status=2");
            try {
                using (SqlCommand cmd = new SqlCommand(sql, connection))
                {
                    SqlParameter param = new SqlParameter();
                    param.ParameterName = "@orderid";
                    param.Value = orderId;
                    param.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@userid";
                    param.Value = userId;
                    param.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(param);

                    cmd.ExecuteNonQuery();
                }
            } catch (SqlException e) {
                throw new FaultException<DatabaseFault>(new DatabaseFault(e.Message), new FaultReason("Could not delete order"));
            }
        }

        public void updateOrder(Order order)
        {
            string sql = isHR ?
                string.Format("UPDATE Orders SET Type=@type,DateBegin=@datebegin,DateEnd=@dateend,Status=@status WHERE Id=@orderid") :
                string.Format("UPDATE Orders SET Type=@type,DateBegin=@datebegin,DateEnd=@dateend WHERE Id=@orderid AND IdUser=@userid AND Status=2");
            try {
                using (SqlCommand cmd = new SqlCommand(sql, connection))
                {
                    SqlParameter param = new SqlParameter();
                    param.ParameterName = "@orderid";
                    param.Value = order.id;
                    param.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@userid";
                    param.Value = userId;
                    param.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@type";
                    param.Value = order.type;
                    param.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@datebegin";
                    param.Value = order.begin;
                    param.SqlDbType = SqlDbType.Date;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@dateend";
                    param.Value = order.end;
                    param.SqlDbType = SqlDbType.Date;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@status";
                    param.Value = order.status;
                    param.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(param);

                    cmd.ExecuteNonQuery();
                }
            } catch (SqlException e) {
                throw new FaultException<DatabaseFault>(new DatabaseFault(e.Message), new FaultReason("Could not update order"));
            }
        }

        public void reAddOrder(int orderId)
        {
            if (isHR) return;
            string sql = string.Format("INSERT INTO Orders(IdUser,Type,DateBegin,DateEnd) SELECT IdUser,Type,DateBegin,DateEnd FROM Orders WHERE Id=@orderid AND IdUser=@userid");
            try {
                using (SqlCommand cmd = new SqlCommand(sql, connection))
                {
                    SqlParameter param = new SqlParameter();
                    param.ParameterName = "@orderid";
                    param.Value = orderId;
                    param.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@userid";
                    param.Value = userId;
                    param.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(param);

                    cmd.ExecuteNonQuery();
                }
            } catch (SqlException e) {
                throw new FaultException<DatabaseFault>(new DatabaseFault(e.Message), new FaultReason("Could not readd order"));
            }
        }

        public void confirmOrder(int orderId) {
            if (!isHR) return;
            string sql = string.Format("UPDATE Orders SET Status=1 WHERE Id=@orderid");
            try {
                using (SqlCommand cmd = new SqlCommand(sql, connection))
                {
                    SqlParameter param = new SqlParameter();
                    param.ParameterName = "@orderid";
                    param.Value = orderId;
                    param.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(param);

                    cmd.ExecuteNonQuery();
                }
            } catch (SqlException e) {
                throw new FaultException<DatabaseFault>(new DatabaseFault(e.Message), new FaultReason("Could not confirm order"));
            }
        }

        public void rejectOrder(int orderId)
        {
            if (!isHR) return;
            string sql = string.Format("UPDATE Orders SET Status=2 WHERE Id=@orderid");
            try
            {
                using (SqlCommand cmd = new SqlCommand(sql, connection))
                {
                    SqlParameter param = new SqlParameter();
                    param.ParameterName = "@orderid";
                    param.Value = orderId;
                    param.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(param);

                    cmd.ExecuteNonQuery();
                }
            } catch (SqlException e) {
                throw new FaultException<DatabaseFault>(new DatabaseFault(e.Message), new FaultReason("Could not reject order"));
            }
        }
    }
}