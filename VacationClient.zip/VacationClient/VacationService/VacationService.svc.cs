﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace VacationService
{
    // ПРИМЕЧАНИЕ. Команду "Переименовать" в меню "Рефакторинг" можно использовать для одновременного изменения имени класса "Service1" в коде, SVC-файле и файле конфигурации.
    // ПРИМЕЧАНИЕ. Чтобы запустить клиент проверки WCF для тестирования службы, выберите элементы Service1.svc или Service1.svc.cs в обозревателе решений и начните отладку.
    public class VacationService : IVacationService
    {
        public void OpenConnection() {
            DatabaseClient.getInstance().connectionOpen();
        }

        public void CloseConnection() {
            DatabaseClient.getInstance().connectionClose();
        }

        public bool Login(string name, string password) {
            bool exists = DatabaseClient.getInstance().login(name, password);
            return exists;
        }

        public bool GetIsHR() {
            return DatabaseClient.getInstance().getIsHR();
        }

        public List<Order> GetMyOrders() {
            return DatabaseClient.getInstance().getMyOrders();
        }

        public List<Order> GetAllOrders() {
            return DatabaseClient.getInstance().getAllOrders();
        }

        public void AddOrder(Order order) {
            DatabaseClient.getInstance().addOrder(order);
        }

        public void DeleteOrder(int orderId) {
            DatabaseClient.getInstance().deleteOrder(orderId);
        }

        public void UpdateOrder(Order order) {
            DatabaseClient.getInstance().updateOrder(order);
        }

        public void ReAddOrder(int orderId) {
            DatabaseClient.getInstance().reAddOrder(orderId);
        }

        public void ConfirmOrder(int orderId) {
            DatabaseClient.getInstance().confirmOrder(orderId);
        }

        public void RejectOrder(int orderId) {
            DatabaseClient.getInstance().rejectOrder(orderId);
        }
    }
}
