﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace VacationService
{
    // ПРИМЕЧАНИЕ. Команду "Переименовать" в меню "Рефакторинг" можно использовать для одновременного изменения имени интерфейса "IService1" в коде и файле конфигурации.
    [ServiceContract]
    public interface IVacationService
    {
        [OperationContract]
        [FaultContract(typeof(DatabaseFault))]
        void OpenConnection();

        [OperationContract]
        [FaultContract(typeof(DatabaseFault))]
        void CloseConnection();

        [OperationContract]
        [FaultContract(typeof(DatabaseFault))]
        bool Login(string name, string password);

        [OperationContract]
        bool GetIsHR();

        [OperationContract]
        [FaultContract(typeof(DatabaseFault))]
        List<Order> GetMyOrders();

        [OperationContract]
        [FaultContract(typeof(DatabaseFault))]
        List<Order> GetAllOrders();

        [OperationContract]
        [FaultContract(typeof(DatabaseFault))]
        void AddOrder(Order order);

        [OperationContract]
        [FaultContract(typeof(DatabaseFault))]
        void DeleteOrder(int orderId);

        [OperationContract]
        [FaultContract(typeof(DatabaseFault))]
        void UpdateOrder(Order order);

        [OperationContract]
        [FaultContract(typeof(DatabaseFault))]
        void ReAddOrder(int orderId);

        [OperationContract]
        [FaultContract(typeof(DatabaseFault))]
        void ConfirmOrder(int orderId);

        [OperationContract]
        [FaultContract(typeof(DatabaseFault))]
        void RejectOrder(int orderId);
    }

    [DataContract]
    public class DatabaseFault
    {
        [DataMember]
        public string message;
        public DatabaseFault(string _message)
        {
            message = _message;
        }
    }

    [DataContract(Name = "OrderType")]
    public enum OrderType {
        [EnumMember]
        yearly = 0,
        [EnumMember]
        extraordinary = 1,
        [EnumMember]
        withoutpay = 2
    }

    [DataContract(Name = "OrderStatus")]
    public enum OrderStatus {
        [EnumMember]
        wait = 0,
        [EnumMember]
        confirm = 1,
        [EnumMember]
        reject = 2
    }

    [DataContract]
    public class Order
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int userId { get; set; }
        [DataMember]
        public string userName { get; set; }
        [DataMember]
        public OrderType type { get; set; }
        [DataMember]
        public DateTime begin { get; set; }
        [DataMember]
        public DateTime end { get; set; }
        [DataMember]
        public OrderStatus status { get; set; }
        [DataMember]
        public string days {
            get { return (end - begin).TotalDays.ToString(); }
            set { }
        }
        public Order() { }
    }
}
